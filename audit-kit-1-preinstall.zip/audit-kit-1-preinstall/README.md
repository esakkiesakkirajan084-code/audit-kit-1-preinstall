# Audit Kit 1 — Pre-install forensics (no Shizuku)

App 1 of 3. Reads what Android already recorded **before this app was installed**,
using only normal permissions you grant by hand. Everything stays on the device.

Requires Android 11+ (API 30).

## The 17 features

| # | Feature | Source |
|---|---------|--------|
| 1 | Deleted apps: last active + duration | UsageEvents |
| 2 | Per-app open/close timeline | UsageEvents |
| 3 | Foreground service history | UsageEvents (types 19/20) |
| 4 | Notification interaction signals | UsageEvents (types 10/12) |
| 5 | User interaction log | UsageEvents (types 6-9) |
| 6 | Standby bucket changes | UsageEvents (type 11) |
| 7 | Reboot history | UsageEvents (types 26/27) |
| 8 | Screen on/off, lock/unlock | UsageEvents (types 15-18) |
| 9 | Daily + weekly usage per app | UsageStatsManager |
| 10 | Per-app data usage (incl. removed-apps bucket) | NetworkStatsManager |
| 11 | Residual APK / OBB / data finder | File scan (All-files access) |
| 12 | APK inspector (package, version, signature, SHA-256) | PackageManager |
| 13 | APK download history (+ owner app) | MediaStore |
| 14 | Install / update time | PackageManager |
| 15 | Install source | PackageManager |
| 16 | Current permissions per app | PackageManager |
| 17 | Clock tampering check (past + live) | UsageEvents + Settings + baseline |

Each report has **Copy** and **Save .txt**.

## Build (no Android Studio needed)

1. Create a GitHub repo and push this folder.
2. Open the **Actions** tab -> *Build APK* -> download the `audit-kit-1-debug-apk` artifact.
3. Install the APK, then grant **Usage Access** and **All-files access** with the two buttons on the home screen.

Local build: `gradle assembleDebug` (Gradle 8.7, JDK 17, Android SDK 34).

## Honest limits (Android, not bugs)

- Android keeps usage **events for only ~7-10 days**; daily/weekly summaries a bit longer. Nothing older exists.
- Features 3-8 depend on the OEM exposing those event types; some phones return fewer.
- Feature 11 cannot read other apps' `Android/data` and `Android/obb` on Android 11+ without Shizuku. That is what App 2 is for.
- Feature 13 only sees APKs still indexed by MediaStore; deleted files drop out.
- Feature 17 "past" detects future-dated or backward-jumping log entries; "live" compares to the previous run. Always-on monitoring belongs to App 3.
- Uses `MANAGE_EXTERNAL_STORAGE` and `QUERY_ALL_PACKAGES`: fine for sideloading/GitHub, not for Play Store.
