package com.auditkit.preinstall

import android.app.usage.NetworkStats
import android.app.usage.NetworkStatsManager
import android.app.usage.UsageEvents
import android.app.usage.UsageStatsManager
import android.content.Context
import android.content.pm.ApplicationInfo
import android.content.pm.PackageInfo
import android.content.pm.PackageManager
import android.content.pm.PermissionInfo
import android.net.ConnectivityManager
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.os.SystemClock
import android.provider.MediaStore
import android.provider.Settings
import java.io.File
import java.security.MessageDigest

class Feature(
    val id: Int,
    val title: String,
    val usage: Boolean,
    val storage: Boolean,
    val run: (Context) -> String
)

data class Ev(val pkg: String?, val type: Int, val time: Long, val bucket: Int)
data class Sess(val pkg: String, val start: Long, val end: Long)

object Features {

    const val APK_INSPECTOR_ID = 12
    private const val DAY = 86_400_000L
    private const val WIN = 30 * DAY

    val all: List<Feature> = listOf(
        Feature(1, "Deleted apps: last active & duration", true, false) { deletedApps(it) },
        Feature(2, "Per-app open/close timeline", true, false) { timeline(it) },
        Feature(3, "Foreground service history", true, false) {
            eventLog(it, setOf(19, 20), 400, "FOREGROUND SERVICE HISTORY")
        },
        Feature(4, "Notification interaction signals", true, false) { notifications(it) },
        Feature(5, "User interaction log", true, false) {
            eventLog(it, setOf(6, 7, 8, 9), 400, "USER / SYSTEM INTERACTION LOG")
        },
        Feature(6, "Standby bucket changes", true, false) {
            eventLog(it, setOf(11), 400, "STANDBY BUCKET CHANGES")
        },
        Feature(7, "Reboot history", true, false) {
            eventLog(it, setOf(26, 27), 200, "REBOOT HISTORY (shutdown/startup)")
        },
        Feature(8, "Screen on/off and lock/unlock history", true, false) {
            eventLog(it, setOf(15, 16, 17, 18), 500, "SCREEN & LOCK HISTORY")
        },
        Feature(9, "Daily and weekly usage per app", true, false) { usageStats(it) },
        Feature(10, "Per-app data usage history", true, false) { dataUsage(it) },
        Feature(11, "Residual APK, OBB, and data finder", true, true) { residual(it) },
        Feature(12, "APK inspector (package, version, signature)", false, false) { "" },
        Feature(13, "APK download history", false, true) { apkHistory(it) },
        Feature(14, "Install and update time of installed apps", false, false) { installTimes(it) },
        Feature(15, "Install source of installed apps", false, false) { installSources(it) },
        Feature(16, "Current permissions per app", false, false) { permissions(it) },
        Feature(17, "Clock tampering check (past and live)", true, false) { clockCheck(it) }
    )

    fun byId(id: Int): Feature? = all.firstOrNull { it.id == id }

    // ---------------------------------------------------------------- helpers

    private val EV = mapOf(
        1 to "ACTIVITY_RESUMED", 2 to "ACTIVITY_PAUSED", 4 to "CONTINUE_PREV_DAY",
        5 to "CONFIG_CHANGE", 6 to "SYSTEM_INTERACTION", 7 to "USER_INTERACTION",
        8 to "SHORTCUT_INVOKED", 9 to "CHOOSER_ACTION", 10 to "NOTIFICATION_SEEN",
        11 to "STANDBY_BUCKET_CHANGED", 12 to "NOTIFICATION_INTERRUPTION",
        15 to "SCREEN_OFF", 16 to "SCREEN_ON", 17 to "LOCKED", 18 to "UNLOCKED",
        19 to "FGSERVICE_START", 20 to "FGSERVICE_STOP", 23 to "ACTIVITY_STOPPED",
        26 to "DEVICE_SHUTDOWN", 27 to "DEVICE_STARTUP"
    )

    private fun evName(t: Int): String = EV[t] ?: "TYPE_$t"

    private fun bucketName(b: Int): String = when (b) {
        10 -> "ACTIVE"
        20 -> "WORKING_SET"
        30 -> "FREQUENT"
        40 -> "RARE"
        45 -> "RESTRICTED"
        50 -> "NEVER"
        else -> "bucket=$b"
    }

    private fun label(c: Context, pkg: String): String = try {
        val pm = c.packageManager
        pm.getApplicationLabel(pm.getApplicationInfo(pkg, 0)).toString()
    } catch (e: Exception) {
        "(not installed)"
    }

    private fun installedPkgs(c: Context): Set<String> =
        c.packageManager.getInstalledPackages(0).map { it.packageName }.toSet()

    private fun isSystem(p: PackageInfo): Boolean =
        ((p.applicationInfo?.flags ?: 0) and ApplicationInfo.FLAG_SYSTEM) != 0

    private fun hex(b: ByteArray): String = b.joinToString("") { "%02x".format(it) }

    private fun sha256(b: ByteArray): String = hex(MessageDigest.getInstance("SHA-256").digest(b))

    private fun events(c: Context, from: Long, to: Long): List<Ev> {
        val usm = c.getSystemService(Context.USAGE_STATS_SERVICE) as UsageStatsManager
        val q = usm.queryEvents(from, to) ?: return emptyList()
        val e = UsageEvents.Event()
        val out = ArrayList<Ev>()
        while (q.hasNextEvent()) {
            q.getNextEvent(e)
            out.add(Ev(e.packageName, e.eventType, e.timeStamp,
                if (e.eventType == 11) e.appStandbyBucket else -1))
        }
        return out
    }

    /** Builds foreground sessions; merges activity hops inside the same app (<=3s gap). */
    private fun sessions(evs: List<Ev>): List<Sess> {
        val open = HashMap<String, Long>()
        val lastIdx = HashMap<String, Int>()
        val out = ArrayList<Sess>()
        for (e in evs) {
            val p = e.pkg ?: continue
            when (e.type) {
                1 -> if (!open.containsKey(p)) open[p] = e.time
                2, 23 -> {
                    val st = open.remove(p)
                    if (st != null) {
                        val idx = lastIdx[p]
                        if (idx != null && st - out[idx].end <= 3000L) {
                            out[idx] = Sess(p, out[idx].start, e.time)
                        } else {
                            out.add(Sess(p, st, e.time))
                            lastIdx[p] = out.size - 1
                        }
                    }
                }
            }
        }
        return out
    }

    // ---------------------------------------------------------------- 1

    private fun deletedApps(c: Context): String {
        val now = System.currentTimeMillis()
        val evs = events(c, now - WIN, now)
        val inst = installedPkgs(c)

        class A(var first: Long = Long.MAX_VALUE, var last: Long = 0L, var total: Long = 0L, var n: Int = 0)

        val m = HashMap<String, A>()
        for (e in evs) {
            val p = e.pkg ?: continue
            if (p in inst) continue
            val a = m.getOrPut(p) { A() }
            if (e.time < a.first) a.first = e.time
            if (e.time > a.last) a.last = e.time
        }
        for (s in sessions(evs)) {
            if (s.pkg in inst) continue
            val a = m.getOrPut(s.pkg) { A() }
            a.total += s.end - s.start
            a.n++
        }
        val sb = StringBuilder("DELETED / UNINSTALLED APPS SEEN IN USAGE LOG\n")
        sb.append("Oldest event available: ").append(U.t(evs.firstOrNull()?.time ?: 0L)).append("\n")
        sb.append("(Android keeps only a few days of event data; older activity is gone.)\n\n")
        if (m.isEmpty()) sb.append("None found in the available window.\n")
        for ((p, a) in m.entries.sortedByDescending { it.value.last }) {
            sb.append(p).append("\n")
            sb.append("  first seen : ").append(U.t(a.first)).append("\n")
            sb.append("  last active: ").append(U.t(a.last)).append("\n")
            sb.append("  fg time    : ").append(U.dur(a.total)).append(" in ").append(a.n).append(" sessions\n\n")
        }
        return sb.toString()
    }

    // ---------------------------------------------------------------- 2

    private fun timeline(c: Context): String {
        val now = System.currentTimeMillis()
        val ss = sessions(events(c, now - WIN, now))
        val sb = StringBuilder("PER-APP OPEN / CLOSE TIMELINE (newest first, max 300)\n")
        sb.append("Total sessions: ").append(ss.size).append("\n\n")
        for (s in ss.asReversed().take(300)) {
            sb.append(U.t(s.start)).append(" -> ").append(U.t(s.end))
                .append("  [").append(U.dur(s.end - s.start)).append("]\n  ")
                .append(label(c, s.pkg)).append(" (").append(s.pkg).append(")\n")
        }
        return sb.toString()
    }

    // ---------------------------------------------------------------- 3,5,6,7,8

    private fun eventLog(c: Context, types: Set<Int>, max: Int, header: String): String {
        val now = System.currentTimeMillis()
        val evs = events(c, now - WIN, now).filter { it.type in types }
        val sb = StringBuilder(header).append("\n")
        sb.append("Events found: ").append(evs.size).append(" (system keeps only a limited window)\n")
        sb.append("Showing newest ").append(minOf(max, evs.size)).append("\n\n")
        for (e in evs.asReversed().take(max)) {
            sb.append(U.t(e.time)).append("  ").append(evName(e.type))
            if (e.type == 11) sb.append(" -> ").append(bucketName(e.bucket))
            sb.append("  ").append(e.pkg ?: "-").append("\n")
        }
        if (evs.isEmpty()) {
            sb.append("No events of this kind. Some Android versions/OEMs do not expose them.\n")
        }
        return sb.toString()
    }

    // ---------------------------------------------------------------- 4

    private fun notifications(c: Context): String {
        val now = System.currentTimeMillis()
        val evs = events(c, now - WIN, now).filter { it.type == 10 || it.type == 12 }
        val cnt = HashMap<String, IntArray>()
        val last = HashMap<String, Long>()
        for (e in evs) {
            val p = e.pkg ?: continue
            val a = cnt.getOrPut(p) { IntArray(2) }
            if (e.type == 10) a[0]++ else a[1]++
            last[p] = maxOf(last[p] ?: 0L, e.time)
        }
        val sb = StringBuilder("NOTIFICATION INTERACTION SIGNALS\n")
        sb.append("seen = user saw it, interruption = it popped up. Availability is OEM dependent.\n\n")
        if (cnt.isEmpty()) sb.append("No notification events exposed on this device.\n")
        for ((p, a) in cnt.entries.sortedByDescending { it.value[0] + it.value[1] }) {
            sb.append(label(c, p)).append(" (").append(p).append(")\n")
            sb.append("  seen=").append(a[0]).append(" interruptions=").append(a[1])
                .append(" last=").append(U.t(last[p] ?: 0L)).append("\n")
        }
        return sb.toString()
    }

    // ---------------------------------------------------------------- 9

    private fun usageStats(c: Context): String {
        val usm = c.getSystemService(Context.USAGE_STATS_SERVICE) as UsageStatsManager
        val now = System.currentTimeMillis()
        val sb = StringBuilder()

        fun section(name: String, interval: Int, from: Long, topN: Int) {
            sb.append("== ").append(name).append(" ==\n")
            val list = (usm.queryUsageStats(interval, from, now) ?: emptyList())
                .filter { it.totalTimeInForeground > 0 }
            val groups = list.groupBy { it.firstTimeStamp }
            for ((start, items) in groups.entries.sortedByDescending { it.key }) {
                sb.append("\n").append(U.d(start)).append("\n")
                for (u in items.sortedByDescending { it.totalTimeInForeground }.take(topN)) {
                    sb.append("  ").append(label(c, u.packageName)).append(" (").append(u.packageName)
                        .append(") ").append(U.dur(u.totalTimeInForeground)).append("\n")
                }
            }
            if (groups.isEmpty()) sb.append("(no data)\n")
            sb.append("\n")
        }

        section("DAILY (last 8 days, top 12 per day)", UsageStatsManager.INTERVAL_DAILY, now - 8 * DAY, 12)
        section("WEEKLY (last 5 weeks, top 12 per week)", UsageStatsManager.INTERVAL_WEEKLY, now - 35 * DAY, 12)
        return sb.toString()
    }

    // ---------------------------------------------------------------- 10

    private fun dataUsage(c: Context): String {
        val nsm = c.getSystemService(Context.NETWORK_STATS_SERVICE) as NetworkStatsManager
        val now = System.currentTimeMillis()
        val from = now - WIN
        val sb = StringBuilder("PER-APP DATA USAGE (last 30 days)\n\n")

        fun agg(type: Int): Map<Int, Long> {
            val m = HashMap<Int, Long>()
            val st = nsm.querySummary(type, null, from, now)
            val b = NetworkStats.Bucket()
            while (st.hasNextBucket()) {
                st.getNextBucket(b)
                m[b.uid] = (m[b.uid] ?: 0L) + b.rxBytes + b.txBytes
            }
            st.close()
            return m
        }

        val wifi = try { agg(ConnectivityManager.TYPE_WIFI) } catch (e: Exception) {
            sb.append("Wi-Fi stats error: ").append(e).append("\n"); emptyMap()
        }
        val mobile = try { agg(ConnectivityManager.TYPE_MOBILE) } catch (e: Exception) {
            sb.append("Mobile stats error: ").append(e).append("\n"); emptyMap()
        }
        val uids = (wifi.keys + mobile.keys)
        val pm = c.packageManager
        fun name(uid: Int): String = when (uid) {
            -4 -> "REMOVED/DELETED APPS (aggregate)"
            -5 -> "Tethering"
            1000 -> "Android system"
            else -> {
                val pk = pm.getPackagesForUid(uid)
                if (pk == null || pk.isEmpty()) "uid $uid" else
                    label(c, pk[0]) + " (" + pk[0] + ")" + if (pk.size > 1) " +${pk.size - 1} shared" else ""
            }
        }
        sb.append("Wi-Fi / Mobile (rx+tx)\n\n")
        for (u in uids.sortedByDescending { (wifi[it] ?: 0L) + (mobile[it] ?: 0L) }.take(60)) {
            sb.append(name(u)).append("\n  wifi=").append(U.size(wifi[u] ?: 0L))
                .append("  mobile=").append(U.size(mobile[u] ?: 0L)).append("\n")
        }
        return sb.toString()
    }

    // ---------------------------------------------------------------- 11

    private fun residual(c: Context): String {
        if (!Environment.isExternalStorageManager()) return "All-files access is required."
        val inst = installedPkgs(c)
        val root = Environment.getExternalStorageDirectory()
        val pat = Regex("^[a-z][a-z0-9_]*(\\.[a-z0-9_]+){2,}$")
        val apks = ArrayList<File>()
        val dirs = ArrayList<File>()
        var scanned = 0

        fun walk(f: File, depth: Int) {
            if (scanned > 60000 || depth > 5) return
            val kids = f.listFiles() ?: return
            for (k in kids) {
                scanned++
                if (k.isDirectory) {
                    if (pat.matches(k.name) && k.name !in inst) dirs.add(k)
                    walk(k, depth + 1)
                } else if (k.name.endsWith(".apk", ignoreCase = true)) {
                    apks.add(k)
                }
            }
        }
        walk(root, 0)

        val sb = StringBuilder("RESIDUAL FINDER\nScanned entries: $scanned\n\n")
        sb.append("== Folders named like uninstalled packages ==\n")
        if (dirs.isEmpty()) sb.append("(none)\n")
        for (d in dirs.take(300)) {
            val sz = try { d.walkTopDown().filter { it.isFile }.take(5000).sumOf { it.length() } } catch (e: Exception) { 0L }
            sb.append(d.absolutePath).append("  ").append(U.size(sz))
                .append("  modified ").append(U.t(d.lastModified())).append("\n")
        }

        sb.append("\n== Removed apps' Android/data and Android/obb (best effort) ==\n")
        sb.append("Android 11+ often blocks this; Shizuku app (App 2) covers it fully.\n")
        val now = System.currentTimeMillis()
        val removed = events(c, now - WIN, now).mapNotNull { it.pkg }.filter { it !in inst }.toSet()
        var hit = 0
        for (p in removed) {
            for (sub in listOf("Android/data", "Android/obb", "Android/media")) {
                val f = File(root, "$sub/$p")
                if (f.exists()) { hit++; sb.append(f.absolutePath).append("\n") }
            }
        }
        if (hit == 0) sb.append("(nothing found / not accessible)\n")

        sb.append("\n== APK files on storage ==\n")
        if (apks.isEmpty()) sb.append("(none)\n")
        for (a in apks.sortedByDescending { it.lastModified() }.take(300)) {
            sb.append(a.absolutePath).append("  ").append(U.size(a.length()))
                .append("  ").append(U.t(a.lastModified())).append("\n")
        }
        return sb.toString()
    }

    // ---------------------------------------------------------------- 12

    fun inspectApk(c: Context, uri: Uri): String {
        val f = File(c.cacheDir, "inspect.apk")
        try {
            val ins = c.contentResolver.openInputStream(uri) ?: return "Cannot open file."
            ins.use { i -> f.outputStream().use { o -> i.copyTo(o) } }
            val pm = c.packageManager
            val flags = PackageManager.GET_SIGNING_CERTIFICATES or PackageManager.GET_PERMISSIONS
            val pi = pm.getPackageArchiveInfo(f.absolutePath, flags)
                ?: return "Not a valid APK, or it cannot be parsed."
            pi.applicationInfo?.let {
                it.sourceDir = f.absolutePath
                it.publicSourceDir = f.absolutePath
            }
            val sb = StringBuilder("APK INSPECTOR\n\n")
            sb.append("Label      : ").append(pi.applicationInfo?.loadLabel(pm) ?: "?").append("\n")
            sb.append("Package    : ").append(pi.packageName).append("\n")
            sb.append("Version    : ").append(pi.versionName).append(" (code ").append(pi.longVersionCode).append(")\n")
            sb.append("Min SDK    : ").append(pi.applicationInfo?.minSdkVersion ?: 0).append("\n")
            sb.append("Target SDK : ").append(pi.applicationInfo?.targetSdkVersion ?: 0).append("\n")
            sb.append("File size  : ").append(U.size(f.length())).append("\n")
            val md = MessageDigest.getInstance("SHA-256")
            f.inputStream().use { s ->
                val buf = ByteArray(65536)
                while (true) { val n = s.read(buf); if (n < 0) break; md.update(buf, 0, n) }
            }
            sb.append("File SHA256: ").append(hex(md.digest())).append("\n\n")

            val signers = pi.signingInfo?.apkContentsSigners ?: emptyArray<android.content.pm.Signature>()
            val hashes = signers.map { sha256(it.toByteArray()) }
            sb.append("Signer certificate SHA-256 (").append(hashes.size).append("):\n")
            for (h in hashes) sb.append("  ").append(h).append("\n")

            sb.append("\nInstalled copy:\n")
            try {
                val cur = pm.getPackageInfo(pi.packageName, PackageManager.GET_SIGNING_CERTIFICATES)
                val ch = (cur.signingInfo?.apkContentsSigners ?: emptyArray<android.content.pm.Signature>()).map { sha256(it.toByteArray()) }
                sb.append("  installed version: ").append(cur.versionName).append(" (code ")
                    .append(cur.longVersionCode).append(")\n")
                sb.append("  signature: ").append(if (ch.toSet() == hashes.toSet())
                    "MATCHES this APK" else "DIFFERENT from this APK (update would fail / possible repack)").append("\n")
            } catch (e: PackageManager.NameNotFoundException) {
                sb.append("  not installed\n")
            }

            val perms = pi.requestedPermissions
            sb.append("\nRequested permissions (").append(perms?.size ?: 0).append("):\n")
            perms?.forEach { sb.append("  ").append(it).append("\n") }
            return sb.toString()
        } finally {
            f.delete()
        }
    }

    // ---------------------------------------------------------------- 13

    private fun apkHistory(c: Context): String {
        val sb = StringBuilder("APK DOWNLOAD / FILE HISTORY (MediaStore)\n")
        sb.append("Shows .apk files Android has indexed. Deleted files disappear from the index.\n")
        sb.append("'owner' is the app that created the file (e.g., the browser).\n\n")
        val uri = MediaStore.Files.getContentUri("external")
        val proj = arrayOf(
            MediaStore.MediaColumns.DISPLAY_NAME, MediaStore.MediaColumns.SIZE,
            MediaStore.MediaColumns.DATE_ADDED, MediaStore.MediaColumns.RELATIVE_PATH,
            MediaStore.MediaColumns.OWNER_PACKAGE_NAME
        )
        var n = 0
        try {
            c.contentResolver.query(
                uri, proj, "${MediaStore.MediaColumns.DISPLAY_NAME} LIKE ?", arrayOf("%.apk"),
                "${MediaStore.MediaColumns.DATE_ADDED} DESC"
            )?.use { cur ->
                while (cur.moveToNext() && n < 400) {
                    n++
                    sb.append(U.t(cur.getLong(2) * 1000)).append("  ")
                        .append(cur.getString(0)).append("  ").append(U.size(cur.getLong(1))).append("\n")
                        .append("  path : ").append(cur.getString(3) ?: "-").append("\n")
                        .append("  owner: ").append(cur.getString(4) ?: "-").append("\n")
                }
            }
        } catch (e: Exception) {
            sb.append("Query error: ").append(e).append("\n")
        }
        if (n == 0) sb.append("No APK files indexed.\n")
        return sb.toString()
    }

    // ---------------------------------------------------------------- 14

    private fun installTimes(c: Context): String {
        val pm = c.packageManager
        val apps = pm.getInstalledPackages(0).filter { !isSystem(it) }.sortedByDescending { it.lastUpdateTime }
        val now = System.currentTimeMillis()
        val sb = StringBuilder("INSTALL / UPDATE TIMES (user apps, newest update first)\n\n")
        for (p in apps) {
            val recent = if (now - p.lastUpdateTime < DAY) "  [LAST 24H]" else ""
            sb.append(label(c, p.packageName)).append(" (").append(p.packageName).append(")").append(recent).append("\n")
            sb.append("  installed: ").append(U.t(p.firstInstallTime)).append("\n")
            sb.append("  updated  : ").append(U.t(p.lastUpdateTime)).append("\n")
            sb.append("  version  : ").append(p.versionName).append("\n")
        }
        return sb.toString()
    }

    // ---------------------------------------------------------------- 15

    private val STORES = setOf(
        "com.android.vending", "com.sec.android.app.samsungapps", "com.amazon.venezia",
        "com.huawei.appmarket", "com.xiaomi.mipicks", "com.xiaomi.market",
        "com.heytap.market", "com.oppo.market", "com.vivo.appstore", "org.fdroid.fdroid"
    )

    private fun installSources(c: Context): String {
        val pm = c.packageManager
        val apps = pm.getInstalledPackages(0).filter { !isSystem(it) }
        val sb = StringBuilder("INSTALL SOURCE (user apps)\n")
        sb.append("'unknown/sideload' = no installer recorded or not a known store.\n\n")
        val rows = apps.map { p ->
            var installer: String? = null
            var initiating: String? = null
            var originating: String? = null
            try {
                if (Build.VERSION.SDK_INT >= 30) {
                    val s = pm.getInstallSourceInfo(p.packageName)
                    installer = s.installingPackageName
                    initiating = s.initiatingPackageName
                    originating = s.originatingPackageName
                } else {
                    installer = pm.getInstallerPackageName(p.packageName)
                }
            } catch (e: Exception) { /* leave nulls */ }
            val flag = if (installer == null || installer !in STORES) "unknown/sideload" else "store"
            Triple(flag, p, Triple(installer, initiating, originating))
        }.sortedBy { it.first }
        for ((flag, p, src) in rows) {
            sb.append(label(c, p.packageName)).append(" (").append(p.packageName).append(")  [").append(flag).append("]\n")
            sb.append("  installer : ").append(src.first ?: "-").append("\n")
            sb.append("  initiating: ").append(src.second ?: "-").append("\n")
            sb.append("  originating: ").append(src.third ?: "-").append("\n")
        }
        return sb.toString()
    }

    // ---------------------------------------------------------------- 16

    private fun permissions(c: Context): String {
        val pm = c.packageManager
        val apps = pm.getInstalledPackages(PackageManager.GET_PERMISSIONS).filter { !isSystem(it) }
        val sb = StringBuilder("GRANTED PERMISSIONS PER APP (user apps)\n'!' = dangerous-level permission\n\n")
        for (p in apps.sortedBy { label(c, it.packageName).lowercase() }) {
            val req = p.requestedPermissions ?: continue
            val fl = p.requestedPermissionsFlags ?: continue
            val granted = ArrayList<String>()
            for (i in req.indices) {
                if (i < fl.size && (fl[i] and PackageInfo.REQUESTED_PERMISSION_GRANTED) != 0) {
                    val dangerous = try {
                        pm.getPermissionInfo(req[i], 0).protection == PermissionInfo.PROTECTION_DANGEROUS
                    } catch (e: Exception) { false }
                    granted.add((if (dangerous) "!" else " ") + req[i].removePrefix("android.permission."))
                }
            }
            sb.append(label(c, p.packageName)).append(" (").append(p.packageName).append(")  granted=")
                .append(granted.size).append("/").append(req.size).append("\n")
            for (g in granted.sortedBy { if (it.startsWith("!")) 0 else 1 }) sb.append("  ").append(g).append("\n")
        }
        return sb.toString()
    }

    // ---------------------------------------------------------------- 17

    private fun clockCheck(c: Context): String {
        val now = System.currentTimeMillis()
        val el = SystemClock.elapsedRealtime()
        val sb = StringBuilder("CLOCK TAMPERING CHECK\n\n")
        val cr = c.contentResolver

        val autoTime = Settings.Global.getInt(cr, Settings.Global.AUTO_TIME, -1)
        val autoTz = Settings.Global.getInt(cr, Settings.Global.AUTO_TIME_ZONE, -1)
        sb.append("Automatic date & time : ").append(when (autoTime) { 1 -> "ON"; 0 -> "OFF  <-- manual clock possible"; else -> "unknown" }).append("\n")
        sb.append("Automatic time zone   : ").append(when (autoTz) { 1 -> "ON"; 0 -> "OFF"; else -> "unknown" }).append("\n")
        sb.append("Now (wall clock)      : ").append(U.t(now)).append("\n")
        sb.append("Estimated boot time   : ").append(U.t(now - el)).append("\n\n")

        // Past: scan usage events
        val evs = events(c, now - WIN, now)
        sb.append("-- PAST (usage event log) --\n")
        var findings = 0
        var future = 0
        for (e in evs) if (e.time > now + 60_000L) future++
        if (future > 0) { findings++; sb.append("FLAG: ").append(future).append(" events are dated in the FUTURE.\n") }
        var prev = 0L
        for (e in evs) {
            if (prev != 0L && e.time < prev - 2000L) {
                findings++
                sb.append("FLAG: time went BACKWARD ").append(U.t(prev)).append(" -> ").append(U.t(e.time)).append("\n")
            }
            prev = maxOf(prev, e.time)
            if (findings > 20) break
        }
        val lastStartup = evs.lastOrNull { it.type == 27 }?.time ?: 0L
        if (lastStartup > 0L) {
            val diff = Math.abs((now - el) - lastStartup)
            sb.append("Last DEVICE_STARTUP event: ").append(U.t(lastStartup)).append("  (diff vs boot estimate ").append(diff / 1000).append("s)\n")
            if (diff > 5 * 60_000L) { findings++; sb.append("FLAG: boot estimate disagrees with the recorded startup by more than 5 min -> clock was changed since boot.\n") }
        }
        if (findings == 0) sb.append("No anomalies found in the available log.\n")

        // Live: compare with the baseline saved at the previous check
        sb.append("\n-- LIVE (vs. previous check in this app) --\n")
        val sp = c.getSharedPreferences("clock", Context.MODE_PRIVATE)
        val savedBoot = sp.getLong("boot", 0L)
        val savedWall = sp.getLong("wall", 0L)
        val bootNow = now - el
        if (savedBoot == 0L) {
            sb.append("First run: baseline stored. Run again later to compare.\n")
        } else {
            val drift = bootNow - savedBoot
            if (Math.abs(drift) <= 120_000L) {
                sb.append("OK: clock is consistent with the previous check (drift ").append(drift / 1000).append("s).\n")
            } else if (lastStartup > savedWall) {
                sb.append("Device rebooted since last check; baseline reset.\n")
            } else {
                sb.append("FLAG: wall clock moved by ").append(drift / 1000).append("s relative to the monotonic clock with NO reboot -> clock was changed.\n")
            }
            sb.append("Previous check: ").append(U.t(savedWall)).append("\n")
        }
        sp.edit().putLong("boot", bootNow).putLong("wall", now).apply()

        sb.append("\nNote: continuous (always-on) clock monitoring is App 3.\n")
        return sb.toString()
    }
}
