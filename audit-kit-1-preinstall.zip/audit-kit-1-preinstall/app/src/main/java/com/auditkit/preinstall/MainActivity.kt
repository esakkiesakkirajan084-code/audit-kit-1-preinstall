package com.auditkit.preinstall

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.os.Environment
import android.provider.Settings
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ListView
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {

    private lateinit var status: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(24, 24, 24, 24)
        }

        status = TextView(this).apply { textSize = 14f }

        val usageBtn = Button(this).apply {
            text = "Grant Usage Access"
            setOnClickListener { startActivity(Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS)) }
        }
        val filesBtn = Button(this).apply {
            text = "Grant All-files access"
            setOnClickListener { openAllFilesSettings() }
        }

        val list = ListView(this)
        list.adapter = ArrayAdapter(
            this, android.R.layout.simple_list_item_1,
            Features.all.map { "${it.id}. ${it.title}" }
        )
        list.setOnItemClickListener { _, _, pos, _ -> openFeature(Features.all[pos]) }

        root.addView(status)
        root.addView(usageBtn)
        root.addView(filesBtn)
        root.addView(list, LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f))
        setContentView(root)
    }

    override fun onResume() {
        super.onResume()
        val u = if (U.hasUsageAccess(this)) "GRANTED" else "NOT granted"
        val f = if (Environment.isExternalStorageManager()) "GRANTED" else "NOT granted"
        status.text = "Usage Access: $u\nAll-files access: $f"
    }

    private fun openAllFilesSettings() {
        try {
            startActivity(
                Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION,
                    Uri.parse("package:$packageName"))
            )
        } catch (e: Exception) {
            startActivity(Intent(Settings.ACTION_MANAGE_ALL_FILES_ACCESS_PERMISSION))
        }
    }

    private fun openFeature(f: Feature) {
        if (f.usage && !U.hasUsageAccess(this)) {
            Toast.makeText(this, "Grant Usage Access first", Toast.LENGTH_LONG).show()
            startActivity(Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS))
            return
        }
        if (f.storage && !Environment.isExternalStorageManager()) {
            Toast.makeText(this, "Grant All-files access first", Toast.LENGTH_LONG).show()
            openAllFilesSettings()
            return
        }
        if (f.id == Features.APK_INSPECTOR_ID) {
            val pick = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
                addCategory(Intent.CATEGORY_OPENABLE)
                type = "*/*"
            }
            startActivityForResult(pick, REQ_PICK_APK)
            return
        }
        startActivity(Intent(this, ReportActivity::class.java).putExtra("id", f.id))
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == REQ_PICK_APK && resultCode == RESULT_OK && data?.data != null) {
            val i = Intent(this, ReportActivity::class.java)
                .putExtra("id", Features.APK_INSPECTOR_ID)
                .setData(data.data)
                .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            startActivity(i)
        }
    }

    companion object {
        private const val REQ_PICK_APK = 42
    }
}
