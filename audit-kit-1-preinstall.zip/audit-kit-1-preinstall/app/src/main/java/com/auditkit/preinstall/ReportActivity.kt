package com.auditkit.preinstall

import android.app.Activity
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.graphics.Typeface
import android.os.Bundle
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast

class ReportActivity : Activity() {

    private var report: String = ""
    private lateinit var body: TextView
    private var featureId = 0

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        featureId = intent.getIntExtra("id", 0)
        val feature = Features.byId(featureId)
        title = feature?.title ?: "Report"

        body = TextView(this).apply {
            typeface = Typeface.MONOSPACE
            textSize = 12f
            setTextIsSelectable(true)
            setPadding(16, 16, 16, 16)
            text = "Working..."
        }
        val scroll = ScrollView(this).apply { addView(body) }

        val copyBtn = Button(this).apply {
            text = "Copy"
            setOnClickListener {
                val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                cm.setPrimaryClip(ClipData.newPlainText("report", report))
                Toast.makeText(this@ReportActivity, "Copied", Toast.LENGTH_SHORT).show()
            }
        }
        val saveBtn = Button(this).apply {
            text = "Save .txt"
            setOnClickListener {
                val i = Intent(Intent.ACTION_CREATE_DOCUMENT).apply {
                    addCategory(Intent.CATEGORY_OPENABLE)
                    type = "text/plain"
                    putExtra(Intent.EXTRA_TITLE, "audit_report_$featureId.txt")
                }
                startActivityForResult(i, REQ_SAVE)
            }
        }
        val bar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            addView(copyBtn, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
            addView(saveBtn, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        }
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            addView(bar)
            addView(scroll, LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f))
        }
        setContentView(root)

        val uri = intent.data
        Thread {
            val out = try {
                if (featureId == Features.APK_INSPECTOR_ID) {
                    if (uri == null) "No APK selected." else Features.inspectApk(this, uri)
                } else {
                    feature?.run?.invoke(this) ?: "Unknown feature."
                }
            } catch (t: Throwable) {
                "Error: $t"
            }
            runOnUiThread {
                report = out
                body.text = out
            }
        }.start()
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == REQ_SAVE && resultCode == RESULT_OK && data?.data != null) {
            try {
                contentResolver.openOutputStream(data.data!!)?.use {
                    it.write(report.toByteArray(Charsets.UTF_8))
                }
                Toast.makeText(this, "Saved", Toast.LENGTH_SHORT).show()
            } catch (e: Exception) {
                Toast.makeText(this, "Save failed: $e", Toast.LENGTH_LONG).show()
            }
        }
    }

    companion object {
        private const val REQ_SAVE = 7
    }
}
