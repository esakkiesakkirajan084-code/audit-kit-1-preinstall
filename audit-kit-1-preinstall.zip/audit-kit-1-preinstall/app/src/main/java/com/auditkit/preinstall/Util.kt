package com.auditkit.preinstall

import android.app.AppOpsManager
import android.content.Context
import android.os.Process
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

object U {
    private val full = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US)
    private val day = SimpleDateFormat("yyyy-MM-dd", Locale.US)

    fun t(ms: Long): String = if (ms <= 0L) "-" else synchronized(full) { full.format(Date(ms)) }
    fun d(ms: Long): String = if (ms <= 0L) "-" else synchronized(day) { day.format(Date(ms)) }

    fun dur(ms: Long): String {
        val s = ms / 1000
        return "%dh %02dm %02ds".format(s / 3600, (s % 3600) / 60, s % 60)
    }

    fun size(b: Long): String = when {
        b >= 1L shl 30 -> "%.2f GB".format(b / (1024.0 * 1024 * 1024))
        b >= 1L shl 20 -> "%.2f MB".format(b / (1024.0 * 1024))
        b >= 1L shl 10 -> "%.1f KB".format(b / 1024.0)
        else -> "$b B"
    }

    fun hasUsageAccess(ctx: Context): Boolean {
        val ops = ctx.getSystemService(Context.APP_OPS_SERVICE) as AppOpsManager
        val mode = ops.unsafeCheckOpNoThrow(
            AppOpsManager.OPSTR_GET_USAGE_STATS, Process.myUid(), ctx.packageName
        )
        return mode == AppOpsManager.MODE_ALLOWED
    }
}
